#!/bin/bash
# MCP Ghidra5 Windows Service - Docker Test Runner
# ================================================
# This script builds and runs comprehensive integration tests
# in a Docker environment to validate Windows service functionality.

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"
DOCKER_DIR="$SCRIPT_DIR/docker"

echo "🐳 MCP Ghidra5 Windows Service - Docker Integration Testing"
echo "=========================================================="
echo ""
echo "Project Root: $PROJECT_ROOT"
echo "Docker Context: $DOCKER_DIR"
echo ""

# Check if Docker is available
if ! command -v docker &> /dev/null; then
    echo "❌ Docker is not installed or not in PATH"
    echo "   Please install Docker to run integration tests"
    exit 1
fi

if ! docker info &> /dev/null; then
    echo "❌ Docker is not running or not accessible"
    echo "   Please start Docker daemon"
    exit 1
fi

echo "✅ Docker is available and running"
echo ""

# Change to docker directory
cd "$DOCKER_DIR"

echo "🔨 Building Docker test image..."
if docker-compose build --no-cache; then
    echo "✅ Docker image built successfully"
else
    echo "❌ Docker image build failed"
    exit 1
fi

echo ""
echo "🚀 Running integration tests in container..."
echo ""

# Run the container and capture output
if docker-compose up --abort-on-container-exit; then
    echo ""
    echo "✅ Docker integration tests completed successfully"
    TEST_EXIT_CODE=0
else
    echo ""
    echo "❌ Docker integration tests failed"
    TEST_EXIT_CODE=1
fi

echo ""
echo "🧹 Cleaning up containers..."
docker-compose down --remove-orphans

if [ $TEST_EXIT_CODE -eq 0 ]; then
    echo ""
    echo "🎉 All integration tests PASSED!"
    echo ""
    echo "📋 What was validated:"
    echo "  ✅ Service script imports and syntax"
    echo "  ✅ Configuration file parsing"
    echo "  ✅ Environment variable setup"
    echo "  ✅ Ghidra integration availability"
    echo "  ✅ Process management simulation"
    echo ""
    echo "🚀 The MCP Ghidra5 Windows service is ready for deployment!"
else
    echo ""
    echo "❌ Integration tests revealed issues that need to be addressed."
    echo "   Review the test output above for details."
fi

exit $TEST_EXIT_CODE