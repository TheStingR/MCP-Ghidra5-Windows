#!/bin/bash

# MCP-Ghidra5 Windows Project Validation Script (Linux)
# This script validates the project structure and files from Linux environment

# set -e - removed to handle arithmetic operations

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

PROJECT_ROOT="/mnt/storage/MCP-Ghidra5-Windows"
LOG_FILE="${PROJECT_ROOT}/validation-results.log"
PASSED=0
FAILED=0

# Logging functions
log_info() {
    echo -e "${BLUE}ℹ️  $1${NC}"
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] [INFO] $1" >> "$LOG_FILE"
}

log_success() {
    echo -e "${GREEN}✅ $1${NC}"
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] [SUCCESS] $1" >> "$LOG_FILE"
    ((PASSED++))
}

log_warning() {
    echo -e "${YELLOW}⚠️  $1${NC}"
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] [WARNING] $1" >> "$LOG_FILE"
}

log_error() {
    echo -e "${RED}❌ $1${NC}"
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] [ERROR] $1" >> "$LOG_FILE"
    ((FAILED++))
}

# Initialize log file
echo "MCP-Ghidra5 Windows Project Validation - $(date)" > "$LOG_FILE"
echo "========================================" >> "$LOG_FILE"

log_info "Starting MCP-Ghidra5 Windows project validation..."

# Test 1: Project Structure
log_info "Testing project file structure..."

required_files=(
    "MCP-Ghidra5-Windows/src/mcp_ghidra_server_windows.py"
    "MCP-Ghidra5-Windows/src/ghidra_gpt5_mcp.py"
    "MCP-Ghidra5-Windows/src/config/service.conf"
    "MCP-Ghidra5-Windows/scripts/service/mcp_ghidra5_service.py"
    "MCP-Ghidra5-Windows/scripts/service/Install-MCPGhidra5Service.ps1"
    "MCP-Ghidra5-Windows/scripts/service/Manage-MCPGhidra5Service.ps1"
    "MCP-Ghidra5-Windows/scripts/packaging/Build-MCPGhidra5Installer.ps1"
    "tests/windows-docker/docker-compose.yml"
    "tests/windows-docker/Dockerfile.windows"
    "tests/windows-docker/run-windows-tests.ps1"
    "README.md"
)

for file in "${required_files[@]}"; do
    if [[ -f "${PROJECT_ROOT}/${file}" ]]; then
        log_success "File exists: $file"
    else
        log_error "File missing: $file"
    fi
done

# Test 2: Python Syntax Validation
log_info "Testing Python file syntax..."

python_files=(
    "MCP-Ghidra5-Windows/src/mcp_ghidra_server_windows.py"
    "MCP-Ghidra5-Windows/src/ghidra_gpt5_mcp.py"
    "MCP-Ghidra5-Windows/scripts/service/mcp_ghidra5_service.py"
)

for file in "${python_files[@]}"; do
    full_path="${PROJECT_ROOT}/${file}"
    if [[ -f "$full_path" ]]; then
        if python3 -m py_compile "$full_path" 2>/dev/null; then
            log_success "Python syntax valid: $(basename $file)"
        else
            log_error "Python syntax error in: $(basename $file)"
        fi
    else
        log_error "Python file not found: $file"
    fi
done

# Test 3: Configuration File Validation
log_info "Testing configuration files..."

config_file="${PROJECT_ROOT}/MCP-Ghidra5-Windows/src/config/service.conf"
if [[ -f "$config_file" ]]; then
    # Basic INI file structure check
    if grep -q "^\[.*\]$" "$config_file"; then
        log_success "Service configuration file has valid INI structure"
    else
        log_warning "Service configuration file may not have valid INI structure"
    fi
    
    # Check for required sections
    required_sections=("SERVER" "GHIDRA" "LOGGING")
    for section in "${required_sections[@]}"; do
        if grep -q "^\[$section\]$" "$config_file"; then
            log_success "Configuration section found: $section"
        else
            log_warning "Configuration section missing: $section"
        fi
    done
else
    log_error "Service configuration file not found"
fi

# Test 4: PowerShell Script Validation (basic)
log_info "Testing PowerShell scripts (basic validation)..."

ps_files=(
    "MCP-Ghidra5-Windows/scripts/service/Install-MCPGhidra5Service.ps1"
    "MCP-Ghidra5-Windows/scripts/service/Manage-MCPGhidra5Service.ps1"
    "tests/windows-docker/run-windows-tests.ps1"
)

for file in "${ps_files[@]}"; do
    full_path="${PROJECT_ROOT}/${file}"
    if [[ -f "$full_path" ]]; then
        # Basic PowerShell file validation
        if grep -q "param(" "$full_path" || grep -q "function " "$full_path" || grep -q "Write-" "$full_path"; then
            log_success "PowerShell script appears valid: $(basename $file)"
        else
            log_warning "PowerShell script may have issues: $(basename $file)"
        fi
        
        # Check for proper PowerShell headers
        if head -n 5 "$full_path" | grep -q "#Requires\|<#\|param("; then
            log_success "PowerShell script has proper headers: $(basename $file)"
        else
            log_warning "PowerShell script missing proper headers: $(basename $file)"
        fi
    else
        log_error "PowerShell script not found: $file"
    fi
done

# Test 5: Docker Configuration Validation
log_info "Testing Docker configuration..."

docker_compose="${PROJECT_ROOT}/tests/windows-docker/docker-compose.yml"
dockerfile="${PROJECT_ROOT}/tests/windows-docker/Dockerfile.windows"

if [[ -f "$docker_compose" ]]; then
    # Check for required Docker Compose elements
    if grep -q "services:" "$docker_compose" && grep -q "version:" "$docker_compose"; then
        log_success "Docker Compose file has valid structure"
    else
        log_error "Docker Compose file missing required elements"
    fi
    
    # Check for Windows-specific settings
    if grep -q "servercore" "$docker_compose" || grep -q "windows" "$docker_compose"; then
        log_success "Docker Compose configured for Windows containers"
    else
        log_warning "Docker Compose may not be configured for Windows containers"
    fi
else
    log_error "Docker Compose file not found"
fi

if [[ -f "$dockerfile" ]]; then
    # Check Dockerfile structure
    if grep -q "FROM.*servercore" "$dockerfile" && grep -q "SHELL.*powershell" "$dockerfile"; then
        log_success "Dockerfile configured for Windows Server Core"
    else
        log_error "Dockerfile not properly configured for Windows"
    fi
else
    log_error "Dockerfile not found"
fi

# Test 6: Documentation Files
log_info "Testing documentation files..."

doc_files=(
    "README.md"
    "docs/DEPLOYMENT_GUIDE.md"
    "RESTORE_POINT.md"
    "QUICK_RESTORE.md"
)

for file in "${doc_files[@]}"; do
    full_path="${PROJECT_ROOT}/${file}"
    if [[ -f "$full_path" ]]; then
        if [[ $(wc -c < "$full_path") -gt 100 ]]; then
            log_success "Documentation file exists and has content: $(basename $file)"
        else
            log_warning "Documentation file exists but may be empty: $(basename $file)"
        fi
    else
        log_warning "Documentation file not found: $file"
    fi
done

# Test 7: Project Dependencies Check
log_info "Testing project dependencies and imports..."

# Extract Python imports from main files
main_py_file="${PROJECT_ROOT}/MCP-Ghidra5-Windows/src/mcp_ghidra_server_windows.py"
if [[ -f "$main_py_file" ]]; then
    required_imports=("asyncio" "logging" "os" "sys" "json" "winreg" "pathlib")
    for import in "${required_imports[@]}"; do
        if grep -q "import $import" "$main_py_file"; then
            log_success "Required import found: $import"
        else
            log_warning "Required import may be missing: $import"
        fi
    done
fi

# Final Results
echo ""
log_info "========================================="
log_info "VALIDATION SUMMARY"
log_info "========================================="
log_success "Passed Tests: $PASSED"
if [[ $FAILED -gt 0 ]]; then
    log_error "Failed Tests: $FAILED"
else
    log_success "Failed Tests: $FAILED"
fi

total_tests=$((PASSED + FAILED))
if [[ $total_tests -gt 0 ]]; then
    pass_rate=$((PASSED * 100 / total_tests))
else
    pass_rate=0
fi
log_info "Pass Rate: ${pass_rate}%"

if [[ $pass_rate -ge 90 ]]; then
    log_success "✅ PROJECT STATUS: EXCELLENT - Ready for deployment"
    exit_code=0
elif [[ $pass_rate -ge 75 ]]; then
    log_warning "⚠️ PROJECT STATUS: GOOD - Minor issues detected"
    exit_code=1
else
    log_error "❌ PROJECT STATUS: NEEDS ATTENTION - Critical issues found"
    exit_code=2
fi

log_info "Detailed results saved to: $LOG_FILE"
log_info "Validation completed at $(date)"

exit $exit_code