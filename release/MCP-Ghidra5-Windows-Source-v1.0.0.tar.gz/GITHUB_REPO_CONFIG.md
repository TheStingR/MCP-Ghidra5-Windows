# GitHub Repository Configuration

## Repository Description
🏢 Enterprise Windows Service for GPT-5 Powered Ghidra Reverse Engineering | Professional MSI Installer | PowerShell Management | Windows Security Integration | TechSquad Inc. Proprietary Software

## Topics/Tags
- reverse-engineering
- windows
- cybersecurity
- penetration-testing
- ctf
- malware-analysis
- binary-analysis
- exploit-development
- ghidra
- gpt5
- mcp-server
- windows-service
- enterprise
- msi-installer
- powershell
- windows-security

## Repository Settings
- **Visibility**: Public
- **License**: Custom (TechSquad Inc. Proprietary)
- **Issues**: Enabled
- **Projects**: Disabled
- **Wiki**: Disabled
- **Discussions**: Disabled
- **Security**: Enabled (private vulnerability reporting)

## Branch Protection
- **Main branch**: Protected
- **Require PR reviews**: Enabled
- **Dismiss stale reviews**: Enabled
- **Require status checks**: Enabled