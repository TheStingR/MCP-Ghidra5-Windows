# MCP-Ghidra5 Windows - Deployment Instructions

## Quick Start

1. **Prerequisites:**
   - Windows 10/11 or Windows Server 2019/2022
   - Administrator privileges
   - Python 3.11+, Java 11+, Ghidra 11.0+

2. **Installation:**
   ```powershell
   # Run the installer script
   .\scripts\service\Install-MCPGhidra5Service.ps1
   ```

3. **Management:**
   ```powershell
   # Manage the service
   .\scripts\service\Manage-MCPGhidra5Service.ps1 -Action Start
   ```

## Full Documentation

See the `docs/` directory for complete deployment guides, configuration references, and troubleshooting information.

## Support

- GitHub Issues: Report bugs and feature requests
- Documentation: Comprehensive guides in `docs/`
- Validation: Run tests in `tests/windows-docker/`
