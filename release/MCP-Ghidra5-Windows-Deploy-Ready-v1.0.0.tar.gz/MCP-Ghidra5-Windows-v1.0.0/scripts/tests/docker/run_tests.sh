#!/bin/bash
set -e

echo "🐳 MCP Ghidra5 Docker Test Environment"
echo "====================================="
echo ""

echo "📋 Environment Check:"
echo "  Java Version: $(java -version 2>&1 | head -1)"
echo "  Python Version: $(python3 --version)"
echo "  Ghidra Path: $GHIDRA_HEADLESS_PATH"
echo "  Project Dir: $GHIDRA_PROJECT_DIR"
echo ""

echo "🧪 Running Integration Tests:"
echo ""

# Test 1: Server script import
echo "Test 1: Server script import..."
if python3 -c "import sys; sys.path.append('/opt/mcp-ghidra5/src'); import mcp_ghidra_server_windows" 2>/dev/null; then
    echo "  ✅ Server script imports successfully"
else
    echo "  ❌ Server script import failed"
    python3 -c "import sys; sys.path.append('/opt/mcp-ghidra5/src'); import mcp_ghidra_server_windows" || true
fi

# Test 2: Service script validation
echo ""
echo "Test 2: Service script validation..."
if python3 -c "exec(open('/opt/mcp-ghidra5/service/mcp_ghidra5_service.py').read())" 2>/dev/null; then
    echo "  ✅ Service script syntax valid"
else
    echo "  ❌ Service script has syntax issues"
    python3 -c "exec(open('/opt/mcp-ghidra5/service/mcp_ghidra5_service.py').read())" || true
fi

# Test 3: Configuration parsing
echo ""
echo "Test 3: Configuration file parsing..."
python3 -c "
import configparser
config = configparser.ConfigParser()
config.read('/etc/mcp-ghidra5/test.conf')
print('  ✅ Configuration parsed successfully')
print(f'    Sections: {list(config.sections())}')
if 'ENVIRONMENT' in config:
    env_vars = dict(config['ENVIRONMENT'])
    print(f'    Environment variables: {len(env_vars)}')
"

# Test 4: Ghidra availability
echo ""
echo "Test 4: Ghidra availability..."
if [ -x "$GHIDRA_HEADLESS_PATH" ]; then
    echo "  ✅ Ghidra executable found and accessible"
    echo "    Path: $GHIDRA_HEADLESS_PATH"
else
    echo "  ❌ Ghidra executable not found or not accessible"
fi

# Test 5: Process simulation
echo ""
echo "Test 5: Process management simulation..."
python3 -c "
import subprocess
import sys
import time

# Create a simple test process
test_script = '''
import time
import sys
print(\"Test process starting...\", flush=True)
time.sleep(2)
print(\"Test process running...\", flush=True)
time.sleep(1)
print(\"Test process completed\", flush=True)
'''

with open('/tmp/test_process.py', 'w') as f:
    f.write(test_script)

result = subprocess.run([sys.executable, '/tmp/test_process.py'], 
                       capture_output=True, text=True, timeout=10)
if result.returncode == 0:
    print('  ✅ Process simulation successful')
    print(f'    Output lines: {len(result.stdout.strip().split())}')
else:
    print('  ❌ Process simulation failed')
"

echo ""
echo "🎉 Docker integration tests completed!"
echo ""