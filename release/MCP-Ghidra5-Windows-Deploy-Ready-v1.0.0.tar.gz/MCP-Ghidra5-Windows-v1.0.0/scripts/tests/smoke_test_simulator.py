#!/usr/bin/env python3
"""
MCP Ghidra5 Windows Service - Smoke Test Simulator
==================================================

This script simulates the Windows service startup process to validate
that all integration fixes are working correctly before deployment.

It tests:
- Service script path resolution
- Configuration file validation
- Environment variable setup
- Server script compatibility
- Process management simulation
- Health check mechanisms

Copyright (c) 2024 - All Rights Reserved
"""

import os
import sys
import json
import configparser
import subprocess
import tempfile
import shutil
from pathlib import Path
from typing import Dict, List, Tuple, Optional
import traceback

class SmokeTestSimulator:
    """Simulates Windows service operations for validation"""
    
    def __init__(self, project_root: Path):
        self.project_root = project_root
        self.service_dir = project_root / "service"
        self.test_results = []
        self.temp_dirs = []
        
    def log_test(self, test_name: str, status: str, message: str = "", details: Dict = None):
        """Log test result"""
        result = {
            "test": test_name,
            "status": status,  # PASS, FAIL, WARNING
            "message": message,
            "details": details or {}
        }
        self.test_results.append(result)
        
        # Color output
        colors = {"PASS": "\033[92m", "FAIL": "\033[91m", "WARNING": "\033[93m"}
        reset = "\033[0m"
        color = colors.get(status, "")
        
        print(f"{color}[{status}]{reset} {test_name}")
        if message:
            print(f"    {message}")
        if details:
            for key, value in details.items():
                print(f"    {key}: {value}")
        print()
    
    def test_service_script_exists(self) -> bool:
        """Test 1: Validate service script exists"""
        # Updated for new structure
        service_script = self.project_root / "MCP-Ghidra5-Windows" / "scripts" / "service" / "mcp_ghidra5_service.py"
        
        if not service_script.exists():
            self.log_test("Service Script Existence", "FAIL", 
                         f"Service script not found: {service_script}")
            return False
            
        # Check if it's the correct script (should reference mcp_ghidra_server_windows.py)
        content = service_script.read_text()
        
        if "mcp_ghidra_server_windows.py" in content:
            self.log_test("Service Script Existence", "PASS",
                         "Service script found and references correct server script")
        else:
            self.log_test("Service Script Existence", "WARNING",
                         "Service script found but may reference incorrect server script")
        
        return True
    
    def test_server_script_exists(self) -> bool:
        """Test 2: Validate main server script exists"""
        # Check multiple possible locations for new project structure
        possible_paths = [
            self.project_root / "MCP-Ghidra5-Windows" / "src" / "mcp_ghidra_server_windows.py",
            self.project_root / "src" / "mcp_ghidra_server_windows.py",  # Legacy
            self.project_root / "server" / "mcp_ghidra_server_windows.py"  # Legacy
        ]
        
        found = False
        for path in possible_paths:
            if path.exists():
                found = True
                self.log_test("Main Server Script", "PASS",
                             f"Main server script found: {path}")
                break
        
        if not found:
            self.log_test("Main Server Script", "FAIL",
                         "Main server script not found in any expected location",
                         {"searched_paths": [str(p) for p in possible_paths]})
        
        return found
    
    def test_configuration_file(self) -> bool:
        """Test 3: Validate configuration file"""
        # Updated for new structure
        config_file = self.project_root / "MCP-Ghidra5-Windows" / "src" / "config" / "service.conf"
        
        if not config_file.exists():
            self.log_test("Configuration File", "FAIL",
                         f"Configuration file not found: {config_file}")
            return False
        
        try:
            config = configparser.ConfigParser()
            config.read(config_file)
            
            # Check required sections and keys
            required_sections = ['SERVICE', 'ENVIRONMENT', 'LOGGING']
            missing_sections = [s for s in required_sections if s not in config]
            
            if missing_sections:
                self.log_test("Configuration File", "WARNING",
                             f"Missing configuration sections: {missing_sections}")
            
            # Check ENVIRONMENT section for critical variables
            if 'ENVIRONMENT' in config:
                env_vars = dict(config['ENVIRONMENT'])
                critical_vars = ['ghidra_headless_path', 'ghidra_project_dir']
                missing_vars = [v for v in critical_vars if v not in env_vars]
                
                if missing_vars:
                    self.log_test("Configuration File", "WARNING",
                                 f"Missing environment variables: {missing_vars}")
                else:
                    self.log_test("Configuration File", "PASS",
                                 "Configuration file valid with required sections")
            
            return True
            
        except Exception as e:
            self.log_test("Configuration File", "FAIL",
                         f"Configuration file parsing error: {e}")
            return False
    
    def test_environment_variable_setup(self) -> bool:
        """Test 4: Simulate environment variable setup"""
        try:
            # Read configuration to get environment variables
            config_file = self.project_root / "MCP-Ghidra5-Windows" / "src" / "config" / "service.conf"
            config = configparser.ConfigParser()
            config.read(config_file)
            
            if 'ENVIRONMENT' not in config:
                self.log_test("Environment Variables", "WARNING",
                             "No ENVIRONMENT section in config")
                return False
            
            env_vars = dict(config['ENVIRONMENT'])
            
            # Simulate setting environment variables
            test_env = os.environ.copy()
            for key, value in env_vars.items():
                # Convert to uppercase for consistency
                env_key = key.upper()
                test_env[env_key] = value
            
            # Check if critical variables are set
            critical_vars = ['GHIDRA_HEADLESS_PATH', 'GHIDRA_PROJECT_DIR', 
                           'MCP_SERVER_HOST', 'MCP_SERVER_PORT']
            
            missing_vars = []
            set_vars = {}
            
            for var in critical_vars:
                if var in test_env:
                    set_vars[var] = test_env[var]
                else:
                    missing_vars.append(var)
            
            if missing_vars:
                self.log_test("Environment Variables", "WARNING",
                             f"Some variables not set: {missing_vars}",
                             {"set_variables": set_vars})
            else:
                self.log_test("Environment Variables", "PASS",
                             "All critical environment variables configured",
                             {"variables": set_vars})
            
            return True
            
        except Exception as e:
            self.log_test("Environment Variables", "FAIL",
                         f"Environment setup simulation failed: {e}")
            return False
    
    def test_server_script_compatibility(self) -> bool:
        """Test 5: Validate server script can be imported/parsed"""
        server_script_paths = [
            self.project_root / "MCP-Ghidra5-Windows" / "src" / "mcp_ghidra_server_windows.py",
            self.project_root / "src" / "mcp_ghidra_server_windows.py",  # Legacy
            self.project_root / "server" / "mcp_ghidra_server_windows.py"  # Legacy
        ]
        
        server_script = None
        for path in server_script_paths:
            if path.exists():
                server_script = path
                break
        
        if not server_script:
            self.log_test("Server Script Compatibility", "FAIL",
                         "No server script found for compatibility test")
            return False
        
        try:
            # Check if script has required components
            content = server_script.read_text()
            
            required_components = {
                "asyncio import": "import asyncio" in content,
                "main function": "async def main(" in content or "def main(" in content,
                "MCP imports": "from mcp" in content,
                "__name__ == '__main__'": "if __name__ == '__main__':" in content
            }
            
            missing_components = [k for k, v in required_components.items() if not v]
            
            if missing_components:
                self.log_test("Server Script Compatibility", "WARNING",
                             f"Server script may be missing: {missing_components}")
            else:
                self.log_test("Server Script Compatibility", "PASS",
                             "Server script contains expected components")
            
            # Try syntax check
            try:
                compile(content, str(server_script), 'exec')
                self.log_test("Server Script Syntax", "PASS",
                             "Server script syntax is valid")
            except SyntaxError as e:
                self.log_test("Server Script Syntax", "FAIL",
                             f"Server script has syntax errors: {e}")
                return False
            
            return True
            
        except Exception as e:
            self.log_test("Server Script Compatibility", "FAIL",
                         f"Server script compatibility check failed: {e}")
            return False
    
    def test_process_management_simulation(self) -> bool:
        """Test 6: Simulate process management operations"""
        try:
            # Create a simple test script to simulate server process
            test_script = tempfile.NamedTemporaryFile(
                mode='w', suffix='.py', delete=False
            )
            test_script.write("""
import time
import sys

print("Test server starting...")
sys.stdout.flush()

# Simulate server running
for i in range(5):
    time.sleep(1)
    print(f"Server running... {i+1}/5")
    sys.stdout.flush()

print("Test server completed")
""")
            test_script.close()
            
            # Try to run the test script (simulate process start)
            try:
                result = subprocess.run([
                    sys.executable, test_script.name
                ], capture_output=True, text=True, timeout=10)
                
                if result.returncode == 0:
                    self.log_test("Process Management", "PASS",
                                 "Process simulation completed successfully",
                                 {"stdout_lines": len(result.stdout.split('\n'))})
                else:
                    self.log_test("Process Management", "WARNING",
                                 f"Process simulation exited with code {result.returncode}")
                
                # Clean up
                os.unlink(test_script.name)
                return True
                
            except subprocess.TimeoutExpired:
                self.log_test("Process Management", "WARNING",
                             "Process simulation timed out")
                os.unlink(test_script.name)
                return False
                
        except Exception as e:
            self.log_test("Process Management", "FAIL",
                         f"Process management simulation failed: {e}")
            return False
    
    def test_health_check_simulation(self) -> bool:
        """Test 7: Simulate health check mechanisms"""
        try:
            # Simulate process-based health check
            import psutil
            
            # Get current process info (simulate server process)
            current_process = psutil.Process()
            
            # Simulate health check data
            health_data = {
                "pid": current_process.pid,
                "status": current_process.status(),
                "cpu_percent": current_process.cpu_percent(),
                "memory_mb": round(current_process.memory_info().rss / 1024 / 1024, 2),
                "create_time": current_process.create_time()
            }
            
            self.log_test("Health Check Simulation", "PASS",
                         "Process-based health check working",
                         health_data)
            
            return True
            
        except ImportError:
            self.log_test("Health Check Simulation", "WARNING",
                         "psutil not available for health check simulation")
            return False
        except Exception as e:
            self.log_test("Health Check Simulation", "FAIL",
                         f"Health check simulation failed: {e}")
            return False
    
    def test_powershell_scripts_syntax(self) -> bool:
        """Test 8: Basic PowerShell script syntax validation"""
        try:
            ps_scripts = [
                self.project_root / "MCP-Ghidra5-Windows" / "scripts" / "service" / "Install-MCPGhidra5Service.ps1",
                self.project_root / "MCP-Ghidra5-Windows" / "scripts" / "service" / "Manage-MCPGhidra5Service.ps1"
            ]
            
            all_valid = True
            for script in ps_scripts:
                if not script.exists():
                    self.log_test("PowerShell Scripts", "WARNING",
                                 f"PowerShell script not found: {script.name}")
                    continue
                
                # Basic syntax checks
                content = script.read_text(encoding='utf-8-sig')  # Handle BOM
                
                # Check for basic PowerShell structure
                checks = {
                    "param_block": "param(" in content.lower(),
                    "function_definitions": "function " in content.lower(),
                    "proper_comments": content.count("#") > 5,
                    "cmdletbinding": "[CmdletBinding()]" in content
                }
                
                failed_checks = [k for k, v in checks.items() if not v]
                if failed_checks:
                    self.log_test("PowerShell Scripts", "WARNING",
                                 f"{script.name} may have issues: {failed_checks}")
                    all_valid = False
                else:
                    self.log_test("PowerShell Scripts", "PASS",
                                 f"{script.name} appears well-structured")
            
            return all_valid
            
        except Exception as e:
            self.log_test("PowerShell Scripts", "FAIL",
                         f"PowerShell script validation failed: {e}")
            return False
    
    def test_directory_structure(self) -> bool:
        """Test 9: Validate project directory structure"""
        try:
            required_structure = {
                "MCP-Ghidra5-Windows/": "Main project folder",
                "MCP-Ghidra5-Windows/src/": "Source code directory",
                "MCP-Ghidra5-Windows/src/mcp_ghidra_server_windows.py": "Main server script",
                "MCP-Ghidra5-Windows/src/config/service.conf": "Service configuration",
                "MCP-Ghidra5-Windows/scripts/service/mcp_ghidra5_service.py": "Service wrapper",
                "MCP-Ghidra5-Windows/scripts/service/Install-MCPGhidra5Service.ps1": "Installation script",
                "MCP-Ghidra5-Windows/scripts/service/Manage-MCPGhidra5Service.ps1": "Management script",
                "docs/": "Documentation directory"
            }
            
            missing_items = []
            found_items = []
            
            for item_path, description in required_structure.items():
                full_path = self.project_root / item_path
                if full_path.exists():
                    found_items.append(f"{item_path}: {description}")
                else:
                    missing_items.append(f"{item_path}: {description}")
            
            if missing_items:
                self.log_test("Directory Structure", "WARNING",
                             f"Missing items: {len(missing_items)}",
                             {"missing": missing_items, "found": found_items})
            else:
                self.log_test("Directory Structure", "PASS",
                             "All required files and directories present",
                             {"structure": found_items})
            
            return len(missing_items) == 0
            
        except Exception as e:
            self.log_test("Directory Structure", "FAIL",
                         f"Directory structure validation failed: {e}")
            return False
    
    def run_smoke_tests(self) -> Dict:
        """Run all smoke tests"""
        print("🧪 MCP Ghidra5 Windows Service - Smoke Test Suite")
        print("=" * 60)
        print()
        
        tests = [
            self.test_directory_structure,
            self.test_service_script_exists,
            self.test_server_script_exists,
            self.test_configuration_file,
            self.test_environment_variable_setup,
            self.test_server_script_compatibility,
            self.test_process_management_simulation,
            self.test_health_check_simulation,
            self.test_powershell_scripts_syntax
        ]
        
        passed = 0
        failed = 0
        warnings = 0
        
        for test in tests:
            try:
                test()
            except Exception as e:
                self.log_test(f"Test Error: {test.__name__}", "FAIL",
                             f"Test crashed: {e}")
                print(traceback.format_exc())
        
        # Count results
        for result in self.test_results:
            if result['status'] == 'PASS':
                passed += 1
            elif result['status'] == 'FAIL':
                failed += 1
            elif result['status'] == 'WARNING':
                warnings += 1
        
        # Summary
        print("=" * 60)
        print("📊 SMOKE TEST SUMMARY")
        print("=" * 60)
        print(f"✅ Passed:    {passed}")
        print(f"⚠️  Warnings:  {warnings}")
        print(f"❌ Failed:    {failed}")
        print(f"📈 Total:     {len(self.test_results)}")
        print()
        
        # Overall status
        if failed == 0 and warnings <= 2:
            print("🎉 SMOKE TEST: PASSED - Ready for deployment testing")
            overall_status = "READY"
        elif failed == 0:
            print("🟡 SMOKE TEST: PASSED WITH WARNINGS - Review warnings before deployment")
            overall_status = "READY_WITH_WARNINGS"
        else:
            print("🔥 SMOKE TEST: FAILED - Critical issues must be resolved")
            overall_status = "NOT_READY"
        
        print()
        
        return {
            "overall_status": overall_status,
            "passed": passed,
            "warnings": warnings,
            "failed": failed,
            "total": len(self.test_results),
            "results": self.test_results
        }
    
    def cleanup(self):
        """Clean up temporary directories"""
        for temp_dir in self.temp_dirs:
            if os.path.exists(temp_dir):
                shutil.rmtree(temp_dir, ignore_errors=True)


def main():
    """Main execution"""
    # Updated for new structure - go up from scripts/tests to project root
    project_root = Path(__file__).parent.parent.parent.parent
    simulator = SmokeTestSimulator(project_root)
    
    try:
        results = simulator.run_smoke_tests()
        
        # Write results to file
        results_file = project_root / "tests" / "smoke_test_results.json"
        results_file.parent.mkdir(exist_ok=True)
        
        with open(results_file, 'w') as f:
            json.dump(results, f, indent=2, default=str)
        
        print(f"📄 Detailed results saved to: {results_file}")
        
        # Exit code based on results
        if results['overall_status'] == 'READY':
            sys.exit(0)
        elif results['overall_status'] == 'READY_WITH_WARNINGS':
            sys.exit(1)  # Warnings
        else:
            sys.exit(2)  # Failed
            
    except Exception as e:
        print(f"❌ Smoke test suite failed: {e}")
        traceback.print_exc()
        sys.exit(3)
    finally:
        simulator.cleanup()


if __name__ == "__main__":
    main()