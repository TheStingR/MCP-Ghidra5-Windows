#Requires -Version 5.1
#Requires -RunAsAdministrator

<#
.SYNOPSIS
    TechSquad MCP Ghidra5 - Windows Installation Script
    
.DESCRIPTION
    Comprehensive PowerShell installation script for TechSquad MCP Ghidra5 Server
    - Validates system requirements
    - Installs dependencies
    - Configures Windows service
    - Sets up registry entries
    - Configures Windows Firewall
    - Optimizes Windows Defender settings
    
.PARAMETER InstallPath
    Installation directory (default: C:\Program Files\TechSquad\MCP-Ghidra5)
    
.PARAMETER ServiceAccount
    Service account for Windows service (default: LocalSystem)
    
.PARAMETER Port
    TCP port for MCP server (default: 8000)
    
.PARAMETER SkipGhidraCheck
    Skip Ghidra installation validation
    
.PARAMETER Uninstall
    Remove TechSquad MCP Ghidra5 installation
    
.EXAMPLE
    .\Install-TechSquadMCPGhidra5.ps1
    
.EXAMPLE
    .\Install-TechSquadMCPGhidra5.ps1 -InstallPath "C:\TechSquad" -Port 8080
    
.EXAMPLE
    .\Install-TechSquadMCPGhidra5.ps1 -Uninstall
    
.NOTES
    Copyright (c) 2024 TechSquad Inc. - All Rights Reserved
    Author: TheStingR
    Version: 1.0.0
    
    Requires Administrator privileges
    Compatible with Windows 10/11 and Server 2019/2022
#>

[CmdletBinding(DefaultParameterSetName = 'Install')]
param(
    [Parameter(ParameterSetName = 'Install')]
    [string]$InstallPath = "C:\Program Files\TechSquad\MCP-Ghidra5",
    
    [Parameter(ParameterSetName = 'Install')]
    [string]$ServiceAccount = "LocalSystem",
    
    [Parameter(ParameterSetName = 'Install')]
    [int]$Port = 8000,
    
    [Parameter(ParameterSetName = 'Install')]
    [switch]$SkipGhidraCheck,
    
    [Parameter(ParameterSetName = 'Uninstall')]
    [switch]$Uninstall
)

# Script configuration
$ErrorActionPreference = "Stop"
$ProgressPreference = "Continue"
$ServiceName = "TechSquadMCPGhidra5"
$ServiceDisplayName = "TechSquad MCP Ghidra5 Server"
$RegistryPath = "HKLM:\SOFTWARE\TechSquad\MCP-Ghidra5"
$LogPath = "$env:ProgramData\TechSquad\MCP-Ghidra5\logs"
$ConfigPath = "$env:ProgramData\TechSquad\MCP-Ghidra5\config"

# Logo and branding
$TechSquadLogo = @"
 ╔═══════════════════════════════════════════════════════════════╗
 ║                        TechSquad Inc.                         ║
 ║                   MCP Ghidra5 Server v1.0                    ║
 ║              Windows Enterprise Installation                  ║
 ║                                                               ║
 ║     Advanced Reverse Engineering with AI Integration         ║
 ╚═══════════════════════════════════════════════════════════════╝
"@

function Write-TechSquadHeader {
    Clear-Host
    Write-Host $TechSquadLogo -ForegroundColor Cyan
    Write-Host ""
}

function Write-LogMessage {
    param(
        [string]$Message,
        [ValidateSet("Info", "Warning", "Error", "Success")]
        [string]$Level = "Info"
    )
    
    $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    $color = switch ($Level) {
        "Info" { "White" }
        "Warning" { "Yellow" }
        "Error" { "Red" }
        "Success" { "Green" }
    }
    
    Write-Host "[$timestamp] " -NoNewline -ForegroundColor Gray
    Write-Host "[$Level] " -NoNewline -ForegroundColor $color
    Write-Host $Message
    
    # Also log to file if log path exists
    if (Test-Path $LogPath -PathType Container) {
        $logFile = Join-Path $LogPath "installation.log"
        "[$timestamp] [$Level] $Message" | Out-File -FilePath $logFile -Append -Encoding UTF8
    }
}

function Test-AdminPrivileges {
    $currentUser = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = New-Object Security.Principal.WindowsPrincipal($currentUser)
    return $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

function Test-SystemRequirements {
    Write-LogMessage "Validating system requirements..." -Level Info
    
    # Check Windows version
    $osInfo = Get-WmiObject -Class Win32_OperatingSystem
    $majorVersion = [int]$osInfo.Version.Split('.')[0]
    $minorVersion = [int]$osInfo.Version.Split('.')[1]
    $buildNumber = [int]$osInfo.BuildNumber
    
    if ($majorVersion -lt 10) {
        throw "Windows 10 or later required. Current version: $($osInfo.Caption)"
    }
    
    # Check if Windows 10 build is recent enough
    if ($majorVersion -eq 10 -and $buildNumber -lt 18362) {
        Write-LogMessage "Warning: Windows 10 build $buildNumber detected. Recommend build 18362 or later." -Level Warning
    }
    
    # Check RAM
    $totalRAM = [math]::Round((Get-WmiObject -Class Win32_ComputerSystem).TotalPhysicalMemory / 1GB, 1)
    if ($totalRAM -lt 4) {
        throw "Minimum 4GB RAM required. Current: $totalRAM GB"
    }
    
    # Check available disk space
    $systemDrive = Get-WmiObject -Class Win32_LogicalDisk | Where-Object { $_.DeviceID -eq "$($env:SystemDrive)\" }
    $freeSpaceGB = [math]::Round($systemDrive.FreeSpace / 1GB, 1)
    if ($freeSpaceGB -lt 2) {
        throw "Minimum 2GB free space required. Current: $freeSpaceGB GB"
    }
    
    # Check .NET Framework
    $dotNetVersion = Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\NET Framework Setup\NDP\v4\Full\" -Name Release -ErrorAction SilentlyContinue
    if (-not $dotNetVersion -or $dotNetVersion.Release -lt 528040) {
        Write-LogMessage "Warning: .NET Framework 4.8 or later recommended" -Level Warning
    }
    
    Write-LogMessage "System requirements validated successfully" -Level Success
    Write-LogMessage "OS: $($osInfo.Caption) Build $buildNumber" -Level Info
    Write-LogMessage "RAM: $totalRAM GB available" -Level Info
    Write-LogMessage "Free Space: $freeSpaceGB GB available" -Level Info
}

function Find-GhidraInstallation {
    if ($SkipGhidraCheck) {
        Write-LogMessage "Skipping Ghidra installation check" -Level Warning
        return $null
    }
    
    Write-LogMessage "Searching for Ghidra installation..." -Level Info
    
    # Common installation paths
    $searchPaths = @(
        "C:\ghidra\support\analyzeHeadless.bat",
        "C:\Program Files\ghidra\support\analyzeHeadless.bat",
        "C:\Program Files (x86)\ghidra\support\analyzeHeadless.bat",
        "C:\tools\ghidra\support\analyzeHeadless.bat",
        "$env:USERPROFILE\ghidra\support\analyzeHeadless.bat",
        "$env:USERPROFILE\Desktop\ghidra\support\analyzeHeadless.bat"
    )
    
    foreach ($path in $searchPaths) {
        if (Test-Path $path) {
            Write-LogMessage "Found Ghidra at: $path" -Level Success
            return $path
        }
    }
    
    # Check environment variable
    $envPath = $env:GHIDRA_HEADLESS_PATH
    if ($envPath -and (Test-Path $envPath)) {
        Write-LogMessage "Found Ghidra via environment variable: $envPath" -Level Success
        return $envPath
    }
    
    Write-LogMessage "Ghidra installation not found" -Level Warning
    Write-LogMessage "Please install Ghidra from https://ghidra-sre.org/" -Level Warning
    return $null
}

function Install-PythonDependencies {
    Write-LogMessage "Installing Python dependencies..." -Level Info
    
    # Check if Python is available
    $pythonVersion = $null
    try {
        $pythonVersion = python --version 2>&1
        if ($LASTEXITCODE -ne 0) { throw "Python not found" }
    } catch {
        throw "Python 3.8+ required but not found. Please install Python from python.org"
    }
    
    Write-LogMessage "Python version: $pythonVersion" -Level Info
    
    # Install required packages
    $packages = @(
        "aiohttp>=3.8.0",
        "mcp>=0.3.0",
        "pywin32>=300",
        "pathlib",
        "asyncio"
    )
    
    foreach ($package in $packages) {
        Write-LogMessage "Installing $package..." -Level Info
        & python -m pip install $package --upgrade --quiet
        if ($LASTEXITCODE -ne 0) {
            throw "Failed to install $package"
        }
    }
    
    Write-LogMessage "Python dependencies installed successfully" -Level Success
}

function New-InstallationDirectories {
    Write-LogMessage "Creating installation directories..." -Level Info
    
    $directories = @(
        $InstallPath,
        "$InstallPath\src",
        "$InstallPath\scripts",
        "$InstallPath\docs",
        "$InstallPath\logs",
        $LogPath,
        $ConfigPath,
        "$env:ProgramData\TechSquad\MCP-Ghidra5\projects"
    )
    
    foreach ($dir in $directories) {
        if (-not (Test-Path $dir)) {
            New-Item -Path $dir -ItemType Directory -Force | Out-Null
            Write-LogMessage "Created directory: $dir" -Level Info
        }
    }
}

function Install-ServerFiles {
    Write-LogMessage "Installing server files..." -Level Info
    
    # Get script directory
    $scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
    $sourceDir = Split-Path -Parent $scriptDir
    
    # Copy main server file
    $serverSource = Join-Path $sourceDir "src\mcp_ghidra_server_windows.py"
    $serverDest = Join-Path $InstallPath "src\mcp_ghidra_server.py"
    
    if (Test-Path $serverSource) {
        Copy-Item -Path $serverSource -Destination $serverDest -Force
        Write-LogMessage "Installed MCP server: $serverDest" -Level Info
    } else {
        throw "Server source file not found: $serverSource"
    }
    
    # Copy additional scripts and documentation
    $filesToCopy = @{
        "scripts\*.ps1" = "scripts"
        "docs\*.md" = "docs"
    }
    
    foreach ($pattern in $filesToCopy.Keys) {
        $destination = $filesToCopy[$pattern]
        $files = Get-ChildItem -Path (Join-Path $sourceDir $pattern) -ErrorAction SilentlyContinue
        
        foreach ($file in $files) {
            $destPath = Join-Path $InstallPath "$destination\$($file.Name)"
            Copy-Item -Path $file.FullName -Destination $destPath -Force
            Write-LogMessage "Copied: $($file.Name)" -Level Info
        }
    }
}

function Set-RegistryConfiguration {
    Write-LogMessage "Configuring registry settings..." -Level Info
    
    # Create registry keys
    if (-not (Test-Path $RegistryPath)) {
        New-Item -Path $RegistryPath -Force | Out-Null
    }
    
    # Set configuration values
    $registryValues = @{
        "InstallPath" = $InstallPath
        "ServiceName" = $ServiceName
        "Port" = $Port
        "Version" = "1.0.0"
        "InstallDate" = (Get-Date).ToString("yyyy-MM-dd HH:mm:ss")
        "ProjectDirectory" = "$env:ProgramData\TechSquad\MCP-Ghidra5\projects"
    }
    
    # Add Ghidra path if found
    $ghidraPath = Find-GhidraInstallation
    if ($ghidraPath) {
        $registryValues["GhidraPath"] = $ghidraPath
    }
    
    foreach ($name in $registryValues.Keys) {
        Set-ItemProperty -Path $RegistryPath -Name $name -Value $registryValues[$name]
        Write-LogMessage "Registry: $name = $($registryValues[$name])" -Level Info
    }
}

function Install-WindowsService {
    Write-LogMessage "Installing Windows service..." -Level Info
    
    # Check if service already exists
    $existingService = Get-Service -Name $ServiceName -ErrorAction SilentlyContinue
    if ($existingService) {
        Write-LogMessage "Stopping existing service..." -Level Info
        Stop-Service -Name $ServiceName -Force -ErrorAction SilentlyContinue
        & sc.exe delete $ServiceName | Out-Null
        Start-Sleep -Seconds 2
    }
    
    # Create service wrapper script
    $serviceWrapper = @"
import sys
import os
import subprocess
import time
import logging
from pathlib import Path

# Service configuration
SERVICE_NAME = 'TechSquadMCPGhidra5'
INSTALL_PATH = r'$InstallPath'
SERVER_SCRIPT = os.path.join(INSTALL_PATH, 'src', 'mcp_ghidra_server.py')
LOG_PATH = r'$LogPath'

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(os.path.join(LOG_PATH, 'service.log')),
        logging.StreamHandler()
    ]
)

def run_server():
    '''Run the MCP server process'''
    try:
        logging.info(f'Starting MCP server: {SERVER_SCRIPT}')
        process = subprocess.Popen([
            sys.executable, SERVER_SCRIPT
        ], cwd=INSTALL_PATH)
        
        logging.info(f'MCP server started with PID: {process.pid}')
        return process
        
    except Exception as e:
        logging.error(f'Failed to start MCP server: {e}')
        return None

def service_main():
    '''Main service loop'''
    logging.info('TechSquad MCP Ghidra5 Service starting...')
    
    while True:
        try:
            process = run_server()
            if process:
                # Wait for process to complete
                return_code = process.wait()
                logging.warning(f'MCP server exited with code: {return_code}')
            
            # Wait before restart
            logging.info('Restarting in 10 seconds...')
            time.sleep(10)
            
        except KeyboardInterrupt:
            logging.info('Service shutdown requested')
            break
        except Exception as e:
            logging.error(f'Service error: {e}')
            time.sleep(30)

if __name__ == '__main__':
    service_main()
"@
    
    $serviceWrapperPath = Join-Path $InstallPath "service_wrapper.py"
    $serviceWrapper | Out-File -FilePath $serviceWrapperPath -Encoding UTF8
    
    # Create Windows service
    $serviceBinary = "python.exe `"$serviceWrapperPath`""
    
    & sc.exe create $ServiceName binPath= $serviceBinary start= auto DisplayName= $ServiceDisplayName | Out-Null
    
    if ($LASTEXITCODE -eq 0) {
        Write-LogMessage "Windows service created successfully" -Level Success
        
        # Set service description
        & sc.exe description $ServiceName "TechSquad MCP Ghidra5 Server - Advanced reverse engineering with AI integration" | Out-Null
        
        # Configure service recovery
        & sc.exe failure $ServiceName reset= 86400 actions= restart/60000/restart/60000/restart/60000 | Out-Null
        
    } else {
        throw "Failed to create Windows service"
    }
}

function Set-FirewallRules {
    Write-LogMessage "Configuring Windows Firewall..." -Level Info
    
    $ruleName = "TechSquad MCP Ghidra5 Server"
    
    # Remove existing rule if it exists
    Get-NetFirewallRule -DisplayName $ruleName -ErrorAction SilentlyContinue | Remove-NetFirewallRule
    
    # Create new firewall rule
    New-NetFirewallRule -DisplayName $ruleName -Direction Inbound -Protocol TCP -LocalPort $Port -Action Allow -Profile Any | Out-Null
    
    Write-LogMessage "Firewall rule created for port $Port" -Level Success
}

function Set-WindowsDefenderExclusions {
    Write-LogMessage "Configuring Windows Defender exclusions..." -Level Info
    
    try {
        $exclusionPaths = @(
            $InstallPath,
            $LogPath,
            $ConfigPath,
            "$env:ProgramData\TechSquad\MCP-Ghidra5\projects"
        )
        
        foreach ($path in $exclusionPaths) {
            Add-MpPreference -ExclusionPath $path -ErrorAction SilentlyContinue
            Write-LogMessage "Added Defender exclusion: $path" -Level Info
        }
        
        Write-LogMessage "Windows Defender exclusions configured" -Level Success
    } catch {
        Write-LogMessage "Warning: Could not configure Windows Defender exclusions" -Level Warning
    }
}

function Start-TechSquadService {
    Write-LogMessage "Starting TechSquad MCP Ghidra5 service..." -Level Info
    
    try {
        Start-Service -Name $ServiceName
        
        # Wait for service to start
        $timeout = 30
        $elapsed = 0
        
        do {
            Start-Sleep -Seconds 1
            $elapsed++
            $service = Get-Service -Name $ServiceName
        } while ($service.Status -ne "Running" -and $elapsed -lt $timeout)
        
        if ($service.Status -eq "Running") {
            Write-LogMessage "Service started successfully" -Level Success
        } else {
            throw "Service failed to start within $timeout seconds"
        }
        
    } catch {
        Write-LogMessage "Warning: Service did not start automatically. You can start it manually later." -Level Warning
    }
}

function Uninstall-TechSquadMCPGhidra5 {
    Write-LogMessage "Uninstalling TechSquad MCP Ghidra5..." -Level Info
    
    # Stop and remove service
    $service = Get-Service -Name $ServiceName -ErrorAction SilentlyContinue
    if ($service) {
        Write-LogMessage "Stopping service..." -Level Info
        Stop-Service -Name $ServiceName -Force -ErrorAction SilentlyContinue
        & sc.exe delete $ServiceName | Out-Null
        Write-LogMessage "Service removed" -Level Success
    }
    
    # Remove firewall rule
    Get-NetFirewallRule -DisplayName "TechSquad MCP Ghidra5 Server" -ErrorAction SilentlyContinue | Remove-NetFirewallRule
    Write-LogMessage "Firewall rule removed" -Level Info
    
    # Remove registry entries
    if (Test-Path $RegistryPath) {
        Remove-Item -Path $RegistryPath -Recurse -Force
        Write-LogMessage "Registry entries removed" -Level Info
    }
    
    # Remove installation directory
    if (Test-Path $InstallPath) {
        Remove-Item -Path $InstallPath -Recurse -Force
        Write-LogMessage "Installation directory removed" -Level Success
    }
    
    # Remove Windows Defender exclusions
    try {
        $exclusionPaths = @(
            $InstallPath,
            $LogPath,
            $ConfigPath,
            "$env:ProgramData\TechSquad\MCP-Ghidra5\projects"
        )
        
        foreach ($path in $exclusionPaths) {
            Remove-MpPreference -ExclusionPath $path -ErrorAction SilentlyContinue
        }
    } catch {
        # Ignore errors for exclusions
    }
    
    Write-LogMessage "TechSquad MCP Ghidra5 uninstalled successfully" -Level Success
}

function Show-InstallationSummary {
    Write-Host ""
    Write-Host "╔══════════════════════════════════════════════════════════════════╗" -ForegroundColor Green
    Write-Host "║                    Installation Complete!                       ║" -ForegroundColor Green
    Write-Host "╚══════════════════════════════════════════════════════════════════╝" -ForegroundColor Green
    Write-Host ""
    
    Write-Host "Installation Details:" -ForegroundColor Yellow
    Write-Host "  • Install Path: $InstallPath"
    Write-Host "  • Service Name: $ServiceName"
    Write-Host "  • Server Port: $Port"
    Write-Host "  • Log Path: $LogPath"
    Write-Host ""
    
    Write-Host "Next Steps:" -ForegroundColor Yellow
    Write-Host "  1. Configure your OpenAI API key (environment variable: OPENAI_API_KEY)"
    Write-Host "  2. Verify Ghidra installation and configuration"
    Write-Host "  3. Start the service: Start-Service $ServiceName"
    Write-Host "  4. Test the installation: Test-NetConnection localhost -Port $Port"
    Write-Host ""
    
    Write-Host "Management Commands:" -ForegroundColor Yellow
    Write-Host "  • Check service status: Get-Service $ServiceName"
    Write-Host "  • View logs: Get-Content '$LogPath\service.log' -Tail 20"
    Write-Host "  • Uninstall: .$($MyInvocation.MyCommand.Name) -Uninstall"
    Write-Host ""
}

# Main execution
try {
    Write-TechSquadHeader
    
    if (-not (Test-AdminPrivileges)) {
        throw "Administrator privileges required. Please run as Administrator."
    }
    
    if ($Uninstall) {
        Write-Host "Uninstalling TechSquad MCP Ghidra5..." -ForegroundColor Yellow
        Uninstall-TechSquadMCPGhidra5
        Write-Host "Uninstallation completed successfully." -ForegroundColor Green
        exit 0
    }
    
    Write-Host "Installing TechSquad MCP Ghidra5 Server..." -ForegroundColor Yellow
    Write-Host ""
    
    # Create log directory early
    if (-not (Test-Path $LogPath)) {
        New-Item -Path $LogPath -ItemType Directory -Force | Out-Null
    }
    
    # Installation steps
    Test-SystemRequirements
    Install-PythonDependencies
    New-InstallationDirectories
    Install-ServerFiles
    Set-RegistryConfiguration
    Install-WindowsService
    Set-FirewallRules
    Set-WindowsDefenderExclusions
    Start-TechSquadService
    
    Show-InstallationSummary
    
} catch {
    Write-LogMessage "Installation failed: $($_.Exception.Message)" -Level Error
    Write-Host ""
    Write-Host "Installation failed. Please check the error message above and try again." -ForegroundColor Red
    Write-Host "For support, contact TechSquad Inc." -ForegroundColor Yellow
    exit 1
}