# MCP-Ghidra5-Windows

**AI-Powered Reverse Engineering Server - Windows Enterprise Edition**

This is the Windows version of the MCP Ghidra5 project, providing enterprise-grade Windows service integration, PowerShell automation, and Windows-specific features for AI-powered reverse engineering using Ghidra and OpenAI.

## Features

- 🛡️ **Windows Service Integration** - Professional Windows service wrapper with enterprise management
- 🔧 **PowerShell Automation** - Comprehensive PowerShell modules for administration
- 🖥️ **Windows Terminal Integration** - Native Windows Terminal profile and shortcuts
- 📦 **MSI Installer** - Professional Windows installer with WiX Toolset
- 🏢 **Enterprise Ready** - Registry integration, event logging, and corporate deployment support
- 🔐 **Security Features** - Windows Defender integration, privilege escalation, and audit logging

## Quick Start

1. **Download the latest installer** from [Releases](../../releases)
2. **Run as Administrator**: `MCP-Ghidra5-Windows-Setup.msi`
3. **Configure Ghidra path** in the installer or set `GHIDRA_HEADLESS_PATH` environment variable
4. **Start the service**: Open PowerShell as Administrator and run `Start-Service MCPGhidra5Service`

## Documentation

- 📖 [Deployment Guide](docs/DEPLOYMENT_GUIDE.md)
- 🚀 [Quick Start Guide](docs/QUICK_START.md)
- 🛠️ [Administrator Guide](docs/ADMINISTRATOR_GUIDE.md)
- 🔧 [Developer Guide](docs/DEVELOPER_GUIDE.md)
- 📋 [Project Summary](docs/PROJECT_SUMMARY.md)
- 🆕 [Changelog](docs/CHANGELOG.md)

## System Requirements

- **OS**: Windows 10/11 or Windows Server 2019/2022
- **PowerShell**: 5.1 or later
- **Python**: 3.8+ (automatically installed if missing)
- **Java**: 11+ (required for Ghidra)
- **Ghidra**: 11.0+ (automatically configured if in standard locations)
- **RAM**: 4GB minimum, 8GB recommended
- **Disk**: 2GB free space

## Project Structure

```
/
├── README.md                           # This file
├── MCP-Ghidra5-Windows/               # Main project directory
│   ├── src/                           # Source code
│   │   ├── mcp_ghidra_server_windows.py    # Main MCP server
│   │   ├── ghidra_gpt5_mcp.py              # Ghidra integration
│   │   └── config/                         # Configuration files
│   └── scripts/                       # Utility scripts
│       ├── service/                   # Windows service scripts
│       ├── terminal/                  # Terminal integration
│       ├── installation/              # Installation scripts
│       └── packaging/                 # Build and packaging
└── docs/                              # Documentation
    ├── DEPLOYMENT_GUIDE.md
    ├── CHANGELOG.md
    └── PROJECT_SUMMARY.md
```

## License

Copyright (c) 2024 TechSquad. All Rights Reserved.

This software is proprietary and confidential. Unauthorized reproduction or distribution is prohibited.

## Support

- 🐛 [Report Issues](../../issues)
- 💬 [Discussions](../../discussions)
- 📧 Enterprise Support: contact@techsquad.com

---

**Enterprise Windows Integration for MCP Ghidra5** | Built with ❤️ by TechSquad